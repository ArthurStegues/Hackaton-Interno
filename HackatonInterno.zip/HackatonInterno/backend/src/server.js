const mysql = require ('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'magic',
    database: 'habitodb'
});

connection.connect((err) =>{
    if(err) {
        throw err;
    }   else {
        console.log('vai corinthians')
    }
});

module.exports = connection;

//  --- Server ---

const express = require("express");
const cors = require("cors");

const port = 3005;

const app = express();

app.use(cors());
app.use(express.json());

app.listen(port, () => console.log(`sala: ${port}`));

//

// Rota POST /usuario/cadastrar
app.post('/usuario/cadastrar', async (request, response) => {
    const { name, email, pass  } = request.body; 

    // Query para inserir os dados
    let query = "INSERT INTO users(name, email, password) VALUES (?, ?, ?)";

    // Executar a query no banco de dados
    connection.query(query, [name, email, pass], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar usuário",
                error: err
            });
        }
        response.status(201).json({
            success: true,
            message: "Usuário cadastrado com sucesso",
            data: results
        });
    });
});

// -- Login --

app.post('/login', (request, response) => {
    const email = request.body.email;
    const pass = request.body.pass;

    // Verifica se os campos foram enviados corretamente
    if (!email || !pass) {
        return response.status(400).json({
            success: false,
            message: "Campos de email e senha são obrigatórios.",
        });
    }

    // Cria a query SQL para buscar o usuário
    let query = "SELECT id, name, email, password, perfil FROM users WHERE email = ?";
    let params = [email];  // Adiciona o email nos parâmetros

    connection.query(query, params, (err, results) => {
        if (err) {
            console.error("Erro ao consultar o banco de dados:", err);
            return response.status(500).json({
                success: false,
                message: "Erro no servidor.",
            });
        }

        
        if (results.length > 0) {
            const senhaDigitada = pass;
            const senhaBanco = results[0].password;

            // Compara a senha enviada com a senha armazenada no banco de dados
            if (senhaBanco === senhaDigitada) {
                return response.status(200).json({
                    success: true,
                    message: "Login realizado com sucesso!",
                    data: results[0], 
                });
            } else {
                return response.status(400).json({
                    success: false,
                    message: "Credenciais inválidas.",
                });
            }
        } else {
            return response.status(400).json({
                success: false,
                message: "Credenciais inválidas.",
            });
        }
    });
});

// anotações


app.post('/anotacao/cadastrar', async (request, response) => {
    const { titulo, descricao } = request.body; 

    // Query para inserir os dados
    let query = "INSERT INTO anotacoes(titulo, descricao) VALUES (?, ?)";

    // Executar a query no banco de dados
    connection.query(query, [ titulo, descricao ], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar",
                error: err
            });
        }
        response.status(201).json({
            success: true,
            message: "cadastrado com sucesso",
            data: results
        });
    });
});

// Listar anotações
app.get('/anotacoes', (req, res) => {
    connection.query("SELECT * FROM anotacoes", (err, results) => {
      if (err) return res.status(500).json({ message: "Erro ao buscar anotações", error: err });
      res.status(200).json(results);
    });
  });
  
  // Excluir anotação
  app.delete('/anotacao/:id', (req, res) => {
    const { id } = req.params;
    connection.query("DELETE FROM anotacoes WHERE id = ?", [id], (err, results) => {
      if (err) return res.status(500).json({ message: "Erro ao excluir anotação", error: err });
      res.status(200).json({ message: "Anotação excluída com sucesso" });
    });
  });
  
  // Atualizar anotação
  app.put('/anotacao/:id', (req, res) => {
    const { id } = req.params;
    const { titulo, descricao } = req.body;
    connection.query("UPDATE anotacoes SET titulo = ?, descricao = ? WHERE id = ?", [titulo, descricao, id], (err, results) => {
      if (err) return res.status(500).json({ message: "Erro ao atualizar anotação", error: err });
      res.status(200).json({ message: "Anotação atualizada com sucesso" });
    });
  });


