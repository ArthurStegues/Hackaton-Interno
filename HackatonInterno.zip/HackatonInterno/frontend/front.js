async function postar(event) {
    event.preventDefault();
  
    const titulo = document.getElementById('titulo').value;
    const descricao = document.getElementById('descricao').value;
  
    if (!titulo || !descricao) {
      alert("Preencha todos os campos.");
      return;
    }
  
    const data = { titulo, descricao };
  
    try {
      const response = await fetch('http://localhost:3005/anotacao/cadastrar', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
  
      const result = await response.json();
  
      if (response.ok) {
        alert(result.message || "Anotação salva!");
        document.getElementById('titulo').value = '';
        document.getElementById('descricao').value = '';
        carregarAnotacoes();
      } else {
        alert("Erro: " + result.message);
      }
    } catch (error) {
      alert("Erro ao postar anotação");
      console.error(error);
    }
  }
  

// 

// Carregar as anotações ao iniciar a página
window.onload = carregarAnotacoes;

async function carregarAnotacoes() {
  const container = document.getElementById('container-cards');
  container.innerHTML = ''; // limpar antes de renderizar

  try {
    const response = await fetch('http://localhost:3005/anotacoes');
    const anotacoes = await response.json();

    anotacoes.forEach(anotacao => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <h3>${anotacao.titulo}</h3>
        <p>${anotacao.descricao}</p>
        <button onclick="abrirModal(${anotacao.id}, '${anotacao.titulo}', '${anotacao.descricao}')">Editar</button>
        <button onclick="excluirAnotacao(${anotacao.id})">Excluir</button>
      `;
      container.appendChild(card);
    });
  } catch (error) {
    console.error("Erro ao carregar anotações:", error);
  }
}

async function excluirAnotacao(id) {
  if (!confirm("Tem certeza que deseja excluir esta anotação?")) return;

  try {
    const response = await fetch(`http://localhost:3005/anotacao/${id}`, {
      method: "DELETE"
    });

    const result = await response.json();

    if (response.ok) {
      alert("Anotação excluída!");
      carregarAnotacoes();
    } else {
      alert("Erro ao excluir: " + result.message);
    }
  } catch (error) {
    alert("Erro ao excluir anotação.");
    console.error(error);
  }
}

function abrirModal(id, titulo, descricao) {
  const modal = document.getElementById('modal-edicao');
  document.getElementById('edit-id').value = id;
  document.getElementById('edit-titulo').value = titulo;
  document.getElementById('edit-descricao').value = descricao;
  modal.style.display = 'block';
}

function fecharModal() {
  document.getElementById('modal-edicao').style.display = 'none';
}

async function salvarEdicao() {
  const id = document.getElementById('edit-id').value;
  const titulo = document.getElementById('edit-titulo').value;
  const descricao = document.getElementById('edit-descricao').value;

  try {
    const response = await fetch(`http://localhost:3005/anotacao/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titulo, descricao })
    });

    const result = await response.json();

    if (response.ok) {
      alert("Anotação atualizada!");
      fecharModal();
      carregarAnotacoes();
    } else {
      alert("Erro ao atualizar: " + result.message);
    }
  } catch (error) {
    alert("Erro ao salvar edição.");
    console.error(error);
  }
}