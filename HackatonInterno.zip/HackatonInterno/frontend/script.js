// --- CADASTRO ---
async function cadastrar(event) {
    event.preventDefault();  // Previne o comportamento padrão do formulário

    // Coleta os dados do formulário
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const pass = document.getElementById('pass').value;

    // Verifica se os campos estão preenchidos
    if (!name || !email  || !pass) {
        alert("Todos os campos devem ser preenchidos!");
        return;
    }

    // Cria o objeto com os dados a serem enviados para a API
    const data = { name, email, pass };

    try {
        // Realiza a requisição POST para a API
        const response = await fetch('http://localhost:3005/usuario/cadastrar', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        // Converte a resposta em JSON
        const result = await response.json();

        // Lida com a resposta
        if (response.ok) {
            alert(result.message);
        } else {
            alert(`Erro: ${result.message}`);
        }
    } catch (error) {
        console.error('Erro durante o cadastro:', error);
        alert("Ocorreu um erro ao tentar realizar o cadastro.");
    }
}

// --- LOGIN ---  

async function logar(event) {
    event.preventDefault();  // Previne o comportamento padrão do formulário

    // Coleta os dados do formulário
    const email = document.getElementById('email').value;
    const pass = document.getElementById('pass').value;

    // Verifica se os campos estão preenchidos
    if (!email || !pass) {
        alert("Todos os campos devem ser preenchidos!");
        return;
    }

    // Cria o objeto com os dados a serem enviados para a API
    const data = { email, pass };

    try {
        const response = await fetch("http://localhost:3005/login", {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data),
        });

        let results = await response.json();

        if (results.success) {
            alert(results.message);

            // Armazena os dados do usuário no localStorage para persistir o login
            let userData = results.data;
            localStorage.setItem('informacoes', JSON.stringify(userData));

            // Redireciona o usuário para a página index.html
            window.location.href = "home.html";
            
        } else {
            alert(results.message);
        }
    } catch (error) {
        console.error("Erro ao realizar login:", error);
        alert("Erro ao realizar login. Tente novamente mais tarde.");
    }
}

// anotações 


// async function postar(event) {
//     event.preventDefault();

//     const titulo = document.getElementById('titulo').value;
//     const descricao = document.getElementById('descricao').value;

//     if (!titulo || !descricao) {
//       alert("Preencha todos os campos.");
//       return;
//     }

//     const data = { titulo, descricao };

//     try {
//       const response = await fetch('http://localhost:3005/anotacao/cadastrar', {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(data),
//       });

//       const result = await response.json();

//       if (response.ok) {
//         alert(result.message || "Anotação salva!");
//         document.getElementById('titulo').value = '';
//         document.getElementById('descricao').value = '';
//         carregarAnotacoes();
//       } else {
//         alert("Erro: " + result.message);
//       }
//     } catch (error) {
//       alert("Erro ao postar anotação");
//       console.error(error);
//     }
//   }
  
//   async function deletarAnotacao(id) {
//     if (!confirm("Deseja mesmo excluir essa anotação?")) return;
//     await fetch(`http://localhost:3005/anotacao/${id}`, { method: 'DELETE' });
//     carregarAnotacoes();
//   }

//   async function marcarConcluida(id) {
//     await fetch(`http://localhost:3005/anotacao/concluir/${id}`, { method: 'PATCH' });
//     carregarAnotacoes();
//   }

//   async function editarAnotacao(id) {
//     const novoTitulo = prompt("Novo título:");
//     const novaDescricao = prompt("Nova descrição:");
//     if (!novoTitulo || !novaDescricao) return;

//     await fetch(`http://localhost:3005/anotacao/${id}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ titulo: novoTitulo, descricao: novaDescricao })
//     });

//     carregarAnotacoes();
//   }

//   window.onload = carregarAnotacoes;